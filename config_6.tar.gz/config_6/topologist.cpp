#include <cstdlib>
#include <iostream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <string.h>
#include <stdio.h>
#include <unistd.h>

#include <qpid/messaging/Address.h>
#include <qpid/messaging/Connection.h>
#include <qpid/messaging/Message.h>
#include <qpid/messaging/Receiver.h>
#include <qpid/messaging/Sender.h>
#include <qpid/messaging/Session.h>

#include <qpid/types/Variant.h>



using namespace qpid::messaging;
using namespace qpid::types;
using namespace std;





/*========================================================
  A neighbor is a representation of a node's neighbor - 
  from the node's point of view..
========================================================*/
struct
Neighbor
{
  string           name;
  int              next_hop;
  string           next_hop_name;
  int              identity;
  vector<int>      valid_origins;
  vector<string *> valid_origin_names;

  Neighbor ( string, int, int );
  void add_valid_origin ( int valid_origin );
  void add_valid_origin ( string & );
  void finalize_valid_origins ( );
  void print ( FILE * fp, char const * indent );

  bool equal ( Neighbor * that, FILE * fp );

  void set_next_hop_name ( string & );
};





Neighbor::Neighbor ( string _name, 
                     int    _next_hop,
                     int    _identity
                   ) 
                   :
                   name ( _name ),
                   next_hop ( _next_hop ),
                   identity ( _identity )
{
}



void
Neighbor::set_next_hop_name ( string & s )
{
  next_hop_name = s;
}


bool
Neighbor::equal ( Neighbor * that, FILE * fp )
{
  if ( 0 != name.compare ( that->name ) )
  {
    fprintf ( fp, 
              "Neighbor::equal names differ: |%s| != |%s|\n",
              name.c_str(),
              that->name.c_str()
            );
    return false;
  }

  if ( next_hop != that->next_hop )
  {
    fprintf ( fp, 
              "Neighbor::equal next_hop %d != %d\n", 
              next_hop, 
              that->next_hop 
            );
  }

  return true;
}




void
Neighbor::add_valid_origin ( int valid_origin )
{
  valid_origins.push_back ( valid_origin );
}





void
Neighbor::add_valid_origin ( string & valid_origin )
{
  valid_origin_names.push_back ( new string(valid_origin) );
}



bool
sort_string_pointers ( string * s1, string * s2 )
{
  return ( 0 > s1->compare ( * s2 ));
}


void
Neighbor::finalize_valid_origins ( )
{
  sort ( valid_origin_names.begin(), valid_origin_names.end(), sort_string_pointers );
}





void 
Neighbor::print ( FILE * fp, char const * indent )
{
  fprintf ( fp, "%sneighbor: %s\n", indent, name.c_str() );

  if ( next_hop )
  {
    fprintf ( fp, "%s  next hop: %s\n", indent, next_hop_name.c_str() );
  }

  if ( valid_origin_names.size() > 0 )
  {
    fprintf ( fp, "%s  valid origins:\n", indent );
    for ( vector<string *>::iterator i = valid_origin_names.begin();
          i != valid_origin_names.end();
          ++ i
        )
    {
      fprintf ( fp, "%s    %s\n", indent, (*i)->c_str() );
    }
  }
}





/*=======================================================
  A node is the basic unit of the topology.
  The topology is not represented as a graph, in that
  there are no explicit representations of arcs.
  There are only nodes, and the knowledge that they 
  have about their neighboring nodes.
=======================================================*/
struct
Node
{
  string name;
  vector<Neighbor *> neighbors;
  int identity;

  Node ( char const * name );
  void print ( FILE * fp, char const * indent );
  void add_neighbor ( string & name, 
                      int next_hop, 
                      Variant::List & valid_origins,
                      int identity
                    );
  bool equal ( Node * that, FILE * fp );
  Neighbor * get_neighbor_by_name ( char const * name );
  Neighbor * get_neighbor_by_identity ( int identity );
  void translate_valid_origins ( );
};





Node::Node ( char const * _name ) : name(_name)
{
}




void
Node::translate_valid_origins ( )
{
  /*-----------------------------------------------
    Go through all the neighbors of this node.
  -----------------------------------------------*/
  for ( vector<Neighbor *>::iterator neighbor = neighbors.begin();
        neighbor != neighbors.end(); 
        ++ neighbor
      )
  {
    /*------------------------------------------------------
      Go through all the valid origins for this neighbor.
    ------------------------------------------------------*/
    for ( vector<int>::iterator valid_origin = (*neighbor)->valid_origins.begin();
          valid_origin != (*neighbor)->valid_origins.end();
          ++ valid_origin
        )
    {
      /*---------------------------------------------------------------------
        The valid origin is an integer.
        Fetch the neighbor (of this node) that corresponds to that integer.
      ---------------------------------------------------------------------*/
      Neighbor * valid_origin_neighbor = get_neighbor_by_identity ( *valid_origin );

      if ( valid_origin_neighbor )
      {
        /*-----------------------------------------------
          Now we have translated the integer to a name. 
          Add it to the list of valid origin names for 
          this neighbor.
       -----------------------------------------------*/
        (*neighbor)->add_valid_origin ( valid_origin_neighbor->name );
      }
      else
      {
        // This really can't happen.  No, really.
        fprintf ( stderr, 
                  "Node::translate_valid_origins error: cant find vo %d\n", 
                  *valid_origin 
                );
        exit ( 1 );
      }
    }

    (*neighbor)->finalize_valid_origins ( );

    /*-------------------------------------------------
      Now do translation of the next-hop integer of 
      this neighbor, likewise.
    -------------------------------------------------*/
    int next_hop = (*neighbor)->next_hop;

    if ( next_hop )
    {
      Neighbor * next_hop_neighbor = get_neighbor_by_identity ( next_hop );
      if ( next_hop_neighbor )
      {
        (*neighbor)->set_next_hop_name ( next_hop_neighbor->name );
      }
      else
      {
        fprintf ( stderr, 
                  "Node::translate_valid_origins error : can't find %d\n", 
                  next_hop 
                );
      }
    }
  }
}





Neighbor *
Node::get_neighbor_by_name ( char const * name )
{
  for ( vector<Neighbor *>::iterator i = neighbors.begin();
        i != neighbors.end(); 
        ++ i
      )
  {
    if ( ! strcmp ( name, (*i)->name.c_str() ) )
      return *i;
  }

  return 0;
}





Neighbor *
Node::get_neighbor_by_identity ( int identity )
{
  for ( vector<Neighbor *>::iterator i = neighbors.begin();
        i != neighbors.end(); 
        ++ i
      )
  {
    if ( identity == (*i)->identity )
      return *i;
  }

  return 0;
}





bool 
Node::equal ( Node * that_node, FILE * fp )
{
  if ( 0 != name.compare ( that_node->name ) )
  {
    fprintf ( fp, 
              "Mick promised this would never happen.  |%s| != |%s|\n", 
              name.c_str(),
              that_node->name.c_str()
            );

    return false;
  }

  for ( vector<Neighbor *>::iterator i = neighbors.begin();
        i != neighbors.end(); 
        ++ i
      )
  {
    char const * that_neighbor_name =  (*i)->name.c_str();
    Neighbor * that_neighbor = that_node->get_neighbor_by_name ( that_neighbor_name );

    if ( ! that_neighbor )
    {
      fprintf ( fp, 
                "Node |%s| has no neighbor |%s|\n", 
                name.c_str(), 
                that_neighbor_name 
              );
      return false;
    }

    if (! ( (*i)->equal(that_neighbor, fp) ))
      return false;
  }

  return true;
}





void
Node::add_neighbor ( string & name, 
                     int next_hop, 
                     Variant::List & _valid_origins,
                     int identity
                   )
{
  Neighbor * neighbor = new Neighbor ( name, next_hop, identity );
  neighbors.push_back ( neighbor );

  for ( Variant::List::iterator i = _valid_origins.begin();
        i != _valid_origins.end();
        ++ i
      )
  {
    char const * str = (*i).asString().c_str();
    neighbor->add_valid_origin ( atoi ( str ) );
  }
}





void
Node::print ( FILE * fp, char const * indent )
{
  string new_indent(indent);
  new_indent += "  ";

  fprintf ( fp, "%sNode: %s\n", indent, name.c_str() );
  fprintf ( fp, "%s{\n", indent);

  for ( vector<Neighbor *>::iterator i = neighbors.begin();
        i != neighbors.end();
        ++ i
      )
  {
    (*i)->print ( fp, new_indent.c_str() );
  }
  fprintf ( fp, "%s}\n", indent );
}





/*========================================================
  A node list is ... oh, you know what it is.
========================================================*/
struct
NodeList
{
  string       name;
  vector<Node> nodes;

       NodeList ( char const * list_name );
  void add_node  ( char const * node_name );
  void print     ( FILE * fp, const char * indent );
  Node * get_node_by_name ( char const * name );

  bool equal ( NodeList & that, FILE * fp );
};





NodeList::NodeList ( char const * list_name ) : name(list_name)
{
}





void
NodeList::add_node ( char const * node_name )
{
  Node n ( node_name );
  nodes.push_back ( n );
}





void
NodeList::print ( FILE * fp, char const * indent )
{
  string new_indent(indent);
  new_indent += "  ";

  fprintf ( fp, "%sNodeList: %s\n", indent, name.c_str() );
  fprintf ( fp, "%s{\n", indent );

  for ( vector<Node>::iterator i = nodes.begin(); i != nodes.end(); ++ i )
  {
    fprintf ( fp, "\n" );
    (*i).print ( fp, new_indent.c_str() );
  }

  fprintf ( fp, "%s}\n", indent );
}





Node *
NodeList::get_node_by_name ( char const * name )
{
  for ( vector<Node>::iterator i = nodes.begin(); i != nodes.end(); ++ i )
  {
    if ( ! strcmp ( (*i).name.c_str(), name ) )
      return & (*i);
  }
  
  return 0;
}





bool
NodeList::equal ( NodeList & that, FILE * fp )
{
  if ( nodes.size() != that.nodes.size() )
  {
    fprintf ( fp, "nodelists size disagree: %d vs %d\n", nodes.size(), that.nodes.size() );
    return false;
  }

  for ( vector<Node>::iterator i = nodes.begin(); i != nodes.end(); ++ i )
  {
    char const * this_name = (*i).name.c_str();
    Node * that_node = that.get_node_by_name ( this_name );

    if ( ! that_node )
    {
      fprintf ( fp, "NodeList::equal: no node with name |%s|\n", this_name );
      return false;
    }

    if ( ! (*i).equal ( that_node, fp ) )
    {
      return false;
    }
  }

  return true;
}





struct
Topologist
{
  NodeList   * originally_detected_nodes,
             * post_mortem_nodes;
  string       url;
  Connection * connection;
  string       connection_options;

  Session  session;
  Sender   sender;
  Receiver receiver;
  Address  response_addr;



       Topologist   ( );
  void start        ( );
  void get_topology ( );
  void print        ( FILE * fp );
  bool equal        ( FILE * fp );


  private :

    unsigned int _count;
    bool _get_local_node_name     ( NodeList * );
    void _get_nonlocal_node_names ( NodeList * );
    void _send_topology_request   ( string node_name );
    void _get_topology_responses  ( NodeList * );
};





bool
Topologist::equal ( FILE * fp )
{
  return originally_detected_nodes->equal ( * post_mortem_nodes, fp );
}





Topologist::Topologist ( )
{
  _count = 0;
  originally_detected_nodes = new NodeList ( "originally detected nodes" );
  post_mortem_nodes         = new NodeList ( "post mortem nodes" );
  url = "0.0.0.0:20001";
  connection_options = "{protocol:amqp1.0}";
}




void
Topologist::start ( )
{
  connection = new Connection( url, connection_options );

  connection->open();
  session       = connection->createSession();
  sender        = session.createSender("mgmt");
  receiver      = session.createReceiver("#");
  response_addr = receiver.getAddress();
  cout << "response_addr was " << response_addr; 
}





void
Topologist::get_topology ( )
{
  NodeList * nodelist;

  if ( _count == 0 )
  {
    nodelist = originally_detected_nodes;
  }
  else
  {
    nodelist = post_mortem_nodes;
  }

  ++ _count;

  _get_local_node_name     ( nodelist );
  _get_nonlocal_node_names ( nodelist );


  for ( vector<Node>::iterator it = nodelist->nodes.begin();
        it != nodelist->nodes.end();
        ++ it
      )
  {
    _send_topology_request ( (*it).name );
  }

  _get_topology_responses ( nodelist );

  /*----------------------------------------------------
    Now we have received all responses.
    Translate the valid-origins lists into node names.
  ----------------------------------------------------*/
  for ( vector<Node>::iterator i = nodelist->nodes.begin();
        i != nodelist->nodes.end();
        ++ i
      )
  {
    (*i).translate_valid_origins ( );
  }
}





void
Topologist::print ( FILE * fp )
{
  fprintf ( fp, "topology\n" );
  fprintf ( fp, "{\n" );
  originally_detected_nodes->print ( fp, "  " );
  fprintf ( fp, "\n\n" );
  post_mortem_nodes->print ( fp, "  " );
  fprintf ( fp, "}\n" );
}





bool
Topologist::_get_local_node_name ( NodeList * nodelist )
{
  Message request;
  request.setReplyTo(response_addr);
  request.setProperty("x-amqp-to", "amqp:/_local/$management");
  request.setProperty("operation", "QUERY");
  request.setProperty("entityType", "org.apache.qpid.dispatch.router");
  request.setProperty("type", "org.amqp.management" );
  request.setProperty("name", "self");

  Variant::List attrs;

  Variant::Map attr_map;
  attr_map["attributeNames"] = attrs;
  request.setContentObject ( attr_map );

  sender.send(request);
  Message response = receiver.fetch();
  Variant content(response.getContentObject());


  Variant::Map map = content.asMap();

  Variant::List list_o_lists = map["results"].asList();
  Variant::List list = (*(list_o_lists.begin())).asList();
  string long_name = (*(list.begin())).asString();

  size_t qdr_pos = long_name.find ( "QDR." );

  if ( qdr_pos == string::npos )
    return false;

  size_t after_qdr = qdr_pos + 4;

  string name;
  name.append ( long_name.substr(after_qdr) );

  nodelist->add_node ( name.c_str() );
  return true;
}





void
Topologist::_get_nonlocal_node_names ( NodeList * nodelist )
{
  Message request;
  request.setReplyTo(response_addr);
  request.setProperty("x-amqp-to", "amqp:/_local/$management");
  request.setProperty("operation", "GET-MGMT-NODES");
  request.setProperty("type", "org.amqp.management");
  request.setProperty("name", "self");

  sender.send(request);
  Message response = receiver.fetch();
  Variant content(response.getContentObject());


  Variant::List list = content.asList();
  for ( Variant::List::iterator it = list.begin(); it != list.end(); ++ it )
  {
    string long_name = *it;

    size_t qdr_pos = long_name.find ( "QDR." );

    if ( qdr_pos == string::npos )
      continue;

    size_t after_qdr = qdr_pos + 4;

    size_t slash = long_name.find ( "/", after_qdr );

    if ( slash == string::npos )
      continue;

    size_t len = slash - after_qdr;
    string name;
    name.append ( long_name, after_qdr, len );
    nodelist->add_node ( name.c_str() );
  }
}





void
Topologist::_send_topology_request ( string node_name )
{
  string to_addr = "amqp:/_topo/0/QDR." + node_name;
  to_addr.append  ( "/$management" );

  Message request;
  request.setReplyTo(response_addr);
  cerr << "sending topo request to: " << to_addr << "\n\n";
  request.setProperty("x-amqp-to", to_addr );
  request.setProperty("operation", "QUERY");
  request.setProperty("entityType", "org.apache.qpid.dispatch.router.node");
  // no, i don't want this -- but ernie might.
  //request.setProperty("entityType", "org.apache.qpid.dispatch.router.link");
  request.setProperty("type", "org.amqp.management" );
  request.setProperty("name", "self");
  request.setCorrelationId ( node_name );

  Variant::List attrs;

  Variant::Map attr_map;
  attr_map["attributeNames"] = attrs;
  request.setContentObject ( attr_map );
  sender.send(request);
}





void
Topologist::_get_topology_responses ( NodeList * nodelist )
{
  Message response;
  Duration duration(2000);

  receiver.setCapacity ( 100 );

  while ( receiver.get(response, duration) )
  {
    Variant content   = response.getContentObject();
    string  router_id = response.getCorrelationId ( );

    Node * router = 
      nodelist->get_node_by_name ( router_id.c_str() );


    /*----------------------------------------------------------------

        This is an example response from a single node.


        MAP: 
        {
          attributeNames : [ 
                             routerLink, 
                             nextHop, 
                             addr,   ( I call this one "neighbor_name" )
                             validOrigins, 
                             type, 
                             identity, 
                             name
                           ], 
                           
          results : [
                      [
                        2, 
                        0, 
                        RQDR.C, 
                        [5], 
                        org.apache.qpid.dispatch.router.node, 
                        router.node/1, 
                        router.node/1
                      ], 
                      
                      [
                        1, 
                        0, 
                        RQDR.B, 
                        [], 
                        org.apache.qpid.dispatch.router.node, 
                        router.node/2, 
                        router.node/2
                      ], 
                      
                      [
                        3, 
                        0, 
                        RQDR.D, 
                        [5], 
                        org.apache.qpid.dispatch.router.node, 
                        router.node/3, 
                        router.node/3
                      ], 
                      
                      [
                        0, 
                        1, 
                        RQDR.Y, 
                        [5], 
                        org.apache.qpid.dispatch.router.node, 
                        router.node/4, 
                        router.node/4
                      ], 
                      
                      [ 
                        0, 
                        0, 
                        RQDR.X, 
                        [1, 3, 4], 
                        org.apache.qpid.dispatch.router.node, 
                        router.node/5, 
                        router.node/5
                      ]
                    ]
                  }

    ----------------------------------------------------------------*/
    Variant::Map map = content.asMap();

    // cerr << "I am going to crash a router now.\n";
    // exit ( 1 );


    Variant::List response_list = map["results"].asList();
    for ( Variant::List::iterator it = response_list.begin(); 
          it != response_list.end(); 
          ++ it 
        )
    {
      Variant::List neighbor_list = (*it).asList();

      // Parse the list of neighbor info ==========================
      Variant::List::iterator it2 = neighbor_list.begin();

      // router_link ------------------------------------
      int routerLink = atoi((*it2).asString().c_str());
      ++ it2;

      // next_hop ------------------------------------
      int next_hop = atoi((*it2).asString().c_str());
      ++ it2;

      // neighbor_name ------------------------------------
      string neighbor_name = (*it2);
      int len = 5;
      if ( ! strncmp ( "RQDR.", neighbor_name.c_str(), len ) )
      {
        neighbor_name = neighbor_name.substr ( len );
      }
      ++ it2;

      Variant::List::iterator valid_origins_iterator = it2;
      ++ it2;

      // type ------------------------------------
      ++ it2;

      // identity ------------------------------------
      string identity = (*it2);
      len = 12;
      if ( ! strncmp ( "router.node/", identity.c_str(), len ) )
      {
        identity = identity.substr ( len );
      }
      ++ it2;

      // name ------------------------------------
      string name = (*it2);
      ++ it2;


      router->add_neighbor ( neighbor_name, 
                            next_hop,
                            (*valid_origins_iterator).asList(),
                            atoi ( identity.c_str() )
                          );
    }
  }

}





int
main ( int argc, char ** argv )
{
  Topologist topologist;

  topologist.start ( );
  fprintf ( stdout, "Get original topology...\n" );
  topologist.get_topology ( );
  fprintf ( stdout, "done.\n" );

  sleep ( 2 );

  fprintf ( stdout, "Get new topology...\n" );
  topologist.get_topology ( );
  fprintf ( stdout, "done.\n" );

  fprintf ( stdout, "\n\n" );
  topologist.print ( stdout );
  fprintf ( stdout, "\n\n" );

  fprintf ( stdout, "Diffing nodelists...\n" );

  if ( topologist.equal ( stdout ) )
  {
    fprintf ( stdout, "Topologies are identical.\n" );
  }
  else
  {
    fprintf ( stdout, "Topologies differ!\n" );
  }


  return 0;
}





